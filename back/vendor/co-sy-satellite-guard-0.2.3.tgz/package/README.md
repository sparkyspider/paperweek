# @co-sy/satellite-guard

Checks Co-Sy sign-in tokens in a satellite's own back end. The satellite front uses
`@co-sy/satellite-auth` to sign people in. It sends their token to your API as
`Authorization: Bearer <token>`. This package decides whether to believe it.

It checks the signature against Co-Sy's published keys, then the issuer, your project id in the
audience, your app as the minter, and expiry. It reads roles from your project's claim only.
It refuses a token Co-Sy has marked stale. Anything it cannot check, it refuses.

From 0.2.0 it also signs your API in to Co-Sy as the app itself, so the API can ask Co-Sy for
upload and read links into the app's own bucket. See "Talk to Co-Sy as your app" below.

## Install

```sh
npm i ./co-sy-satellite-guard-0.2.1.tgz
```

Node 20.19 or later. Nest 10 or 11 for the Nest part; plain Node needs nothing else.

## Configure

```ts
const cosyAuth = {
  issuer: process.env.COSY_ISSUER!,              // e.g. https://auth.co-sy.org
  projectId: process.env.SATELLITE_PROJECT_ID!,  // your satellite's Zitadel project id
  clientIds: [process.env.SATELLITE_CLIENT_ID!], // the app id your front signs in with
  owningOrgId: process.env.SATELLITE_OWNER_ORG!, // required: only roles this org granted count
  staleCheck: {
    enabled: true,
    url: `${process.env.COSY_API}/api/v1/auth/token-status`,
  },
};
```

These are the same ids your front's `cosySatellite` block in `nuxt.config.ts` already holds.
`staleCheck` must be stated. The route below is available on Co-Sy builds from integration-0929 / Milestone 1.
Until your Co-Sy has it, set `staleCheck.enabled=false`.
The guard then logs one warning at start-up.

`owningOrgId` is required from 0.2.0. Without it the guard will not start, and says so in one
sentence. RS256 is the only signing algorithm accepted, and there is no clock skew allowance:
`algorithms` and `clockToleranceSeconds` may be left out, and any value but `['RS256']` and `0` is
refused. `audience` defaults to `projectId`.
The key-cache settings are `jwksCacheMaxAgeMs`, `jwksCooldownMs` and `jwksTimeoutMs`.

## Use it in Nest

```ts
import { SatelliteGuardModule, RequireRole, SatellitePublic, CurrentSatelliteUser } from '@co-sy/satellite-guard/nest';
import type { SatelliteUser } from '@co-sy/satellite-guard';

@Module({ imports: [SatelliteGuardModule.forRoot(cosyAuth)] })
export class AppModule {}

@Controller('sightings')
export class SightingsController {
  @Get('published')
  @SatellitePublic()                       // no sign-in needed
  list() { /* ... */ }

  @Post()
  @RequireRole('WHALE_PROTECTOR_USER')     // any one of the listed roles
  upload(@CurrentSatelliteUser() me: SatelliteUser) {
    return this.service.create(me.sub);    // key your rows on `sub`
  }
}
```

The guard covers every route once the module is imported. A route opens only with
`@SatellitePublic()`. Roles on a controller and on its route must both be met.
`forRootAsync({ imports, inject, useFactory })` reads config from your config service.

Refusals have the body `{ statusCode, error, message }`:

| Status | `error` | Means |
|---|---|---|
| 401 | `TOKEN_MISSING`, `TOKEN_INVALID`, `TOKEN_EXPIRED`, `WRONG_ISSUER`, `WRONG_AUDIENCE`, `WRONG_CLIENT` | sign in again |
| 401 | `TOKEN_STALE` | access changed; refresh the token once and retry, as with Co-Sy |
| 401 | `APP_TOKEN_REFUSED` | an app's own token was sent as if it were a person's |
| 403 | `ROLE_REQUIRED` | signed in, without the role |
| 503 | `AUTH_UPSTREAM_UNAVAILABLE`, `STALE_CHECK_UNAVAILABLE` | Co-Sy could not be reached; nobody is let in |

## Use it without Nest

```ts
import { createSatelliteVerifier, SatelliteAuthError } from '@co-sy/satellite-guard';

const cosy = createSatelliteVerifier(cosyAuth);  // build once; it holds the key cache
const me = await cosy.verifyAuthorizationHeader(req.headers.authorization);
// me: { sub, name?, email?, emailVerified?, roles, rolesByOrg, actingOrgId?, homeOrg?, clientId, issuedAt, expiresAt, claims }
```

A refusal rejects with a `SatelliteAuthError` carrying `code`, `status` and `message`.
`verify(token, cosyAuth)` does the same in one call, reusing a verifier per config object.

Name and email appear only when Co-Sy's token carries them. Today's access tokens often do not.

## Talk to Co-Sy as your app

Your API never holds a cloud key. It asks Co-Sy, as the app, and Co-Sy answers with short links.
The one-line version:

```ts
const link = await createCosyServiceClient(cosyApp).getUploadLink({ contentType, sizeBytes, md5Base64 });
```

Set it up once:

```ts
import { createCosyServiceClient } from '@co-sy/satellite-guard';

const cosyApp = {
  cosyApiUrl: process.env.COSY_API_URL!,            // http://localhost:3021 locally
  issuer: process.env.COSY_ISSUER!,                 // http://localhost:8080 locally
  platformProjectId: process.env.COSY_PLATFORM_PROJECT_ID!, // the Co-Sy Platform project id
  keyFile: process.env.COSY_SERVICE_KEY_FILE!,      // locally: auth/.machinekey/satellites/<slug>.json
};
const cosyClient = createCosyServiceClient(cosyApp); // build once; it keeps the token
```

Registering the app in Co-Sy makes its machine key. Locally the key lands in
`auth/.machinekey/satellites/<slug>.json` in your Co-Sy checkout. In production it lives in
Secret Manager; pass it as `machineKey` instead of `keyFile`. Never call production from a laptop.

The five calls:

| Call | Co-Sy route | Answers |
|---|---|---|
| `getUploadLink({ contentType, sizeBytes, md5Base64, forPersonId? })` | `POST /api/v1/storage/upload-links` | `{ key, url, method: 'PUT', headers, expiresAt }`: PUT the bytes to `url` with exactly `headers` within ten minutes |
| `confirmUpload(key)` | `POST /api/v1/storage/files/confirm` | `{ key, sizeBytes, md5Base64, state: 'confirmed', confirmedAt }`; safe to repeat |
| `getTemporaryFileUrl(key)` | `POST /api/v1/storage/files/read-link` | `{ url, expiresAt }`: a ten-minute read link to a confirmed file |
| `deleteFile(key)` | `DELETE /api/v1/storage/files?key=` | `{ key, state: 'deleted' }` |
| `myRights()` | `GET /api/v1/apps/me/rights` | `{ app: { slug, name }, orgId, rights }` |

`forPersonId` is the person the upload is for. Co-Sy writes it on its audit line as "stated by
the app". It is data, never authority: your API decides who may upload, with `@RequireRole`.

How it signs in: it signs a five-minute RS256 assertion with the machine key and swaps it at
`<issuer>/oauth/v2/token` for a token whose audience is the Co-Sy Platform project. It reuses that
token until its last minute. When Co-Sy answers `TOKEN_STALE` or `TOKEN_EXPIRED`, it waits about
two seconds, swaps the key once more and retries once.

Every refusal is a `CosyServiceError` with Co-Sy's own sentence as `message`, plus `code` and
`status`. Its own codes are `KEY_UNREADABLE`, `KEY_REFUSED` (the login service said no, and the
sentence says why), `LOGIN_SERVICE_UNAVAILABLE`, `COSY_UNAVAILABLE` and `BAD_ANSWER`. No error,
log line or thrown value ever holds the key.

## Co-Sy side needed

The stale check asks Co-Sy about each token, at most every 20 seconds (`staleCheck.cacheSeconds`,
default 20, never above 25). So a person whose right is removed is refused within about 20 seconds,
inside Co-Sy's 30-second promise (093 AC-10.9). A satellite does not call Co-Sy on every request
(Mark, 14 October 2026: "I don't want a satellite app to make a request to Co-Sy every single time a
user does anything."). An operator who wants a removal refused on the very next request can set
`cacheSeconds: 0`, which asks Co-Sy on every request. A token Co-Sy has called stale is refused
without asking again. The route is available on
Co-Sy builds from integration-0929 / Milestone 1. Until your Co-Sy has it, set `staleCheck.enabled=false`.

```
GET /api/v1/auth/token-status
Authorization: Bearer <the person's own Co-Sy token, as the satellite received it>
```

- Auth: the normal global guards. JwtAuthGuard admits the token on either path. StaleTokenGuard
  then runs as on every route. Not `@Public()`. No right beyond a verified token. No cookie and
  no service credential.
- 200: `{ data: { sub: <token sub>, iat: <token iat>, fresh: true }, meta }`.
- Stale: StaleTokenGuard's own 401, unchanged: `error.code = "TOKEN_STALE"`.
- Any other answer is treated as "cannot check", and the satellite refuses with 503.
- It reads only the in-memory recently-changed list, and returns nothing the token does not say.
  Throttling must allow one call per token per 20 seconds per satellite instance (with
  `cacheSeconds: 0`, one call per satellite request). Co-Sy's own limits apply to this route: 60 a
  minute per person and 300 a minute per calling address.

## Develop

`npm test` runs the suite against a local key set, signed test tokens, and a fake login service
and Co-Sy for the app client. `npm pack` builds.
