# @co-sy/satellite-auth

Sign your app's people in with their Co-Sy account.

## What this is

A **satellite app** is an app that belongs to a co-space but runs on its own website.
Positive Polar's site is one. It has its own pages, its own look, its own domain.

This package gives such an app one thing: **its people sign in with their Co-Sy account.**
No second password. No user list to keep. A person signs in once, and the app knows who
they are, what they are called, and whether they are allowed in.

Add one line to the app's config and one block of settings. That is the whole job.

## Why it matters

Every satellite would otherwise build its own sign-in. Each one a separate password for a
person to forget, and a separate place for an account to be left open after someone leaves.
With this, access is granted and removed in one place — Co-Sy — and every satellite obeys
it the same day.

## Install

```bash
npm install @co-sy/satellite-auth
```

```ts
// nuxt.config.ts
export default defineNuxtConfig({
  modules: ['@co-sy/satellite-auth'],
  cosySatellite: {
    slug: 'whale-protector',
    issuer: 'http://localhost:8080',
    clientId: '392300670897618946',
    satelliteProjectId: '392299806183129090',
    cosyProjectId: '392299905571356674',
    cosyApiBase: 'http://localhost:3051/api',
    requiredRole: 'WHALE_PROTECTOR_USER',
  },
})
```

Those are Positive Polar's real values on the local Zitadel. Your own satellite gets its
own `slug`, `clientId` and `satelliteProjectId`; `cosyProjectId` is the same for everybody.
The `slug` names the app — here, `whale-protector`. Positive Polar is the organisation
that owns it.

A satellite needs two Zitadel applications, one for each place it runs. Use the native
application's id while developing on `http://localhost`. A browser cannot mint tokens over
plain http, so only the native application works there. Use the browser application's id
once the satellite runs on its real https domain. Positive Polar's native id is
`392300670897618946`, the one shown above; its browser id, for production, is
`392299866631503874`.

## Every setting

| Setting | Required | What it is |
|---|---|---|
| `slug` | yes | The co-space registry slug this satellite is registered under. |
| `issuer` | yes | Where Co-Sy's sign-in service lives. |
| `clientId` | yes | This satellite's own sign-in application. Public, no secret. Use the native application's id on `localhost`; use the browser application's id in production. |
| `satelliteProjectId` | yes | This satellite's own Zitadel project — where its roles live. |
| `cosyProjectId` | yes | The shared Co-Sy project — where Co-Sy rights live. |
| `cosyApiBase` | yes | Co-Sy's API, for calls the app makes on the person's behalf. **Must end `/api`** — Co-Sy's controllers sit under `api/v1`, and leaving the suffix off produces 404s that look like an auth problem. |
| `requiredRole` | no | The role a person must hold to use this app. Left out, anyone signed in may in. |
| `scopes` | no | Replaces the default list wholesale. Almost nobody needs this. |
| `callbackPath` | no | Default `/auth/callback`. Must match the application in Zitadel. |
| `postLogoutPath` | no | Default `/`. Must match the application in Zitadel. |
| `enabled` | no | Default `true`. Set `false` and nothing of this package is built into the app at all. |
| `provider` | no | A file of your own supplying hooks. See below. |
| `sessionScope` | no | Default `'browser'`: one sign-in is shared by every tab of this browser on your site, and ends after an hour unused. `'tab'`: each tab signs in on its own, as before 0.1.9. See "Where the session is kept". |
| `idleMinutes` | no | Default `60`. `'browser'` only: a sign-in unused this long is dropped. Leave it alone. |
| `rememberDays` | no | Default `14`. `'browser'` only: the limit instead when the person ticks "Keep me signed in on this device". Leave it alone. |

**There is no client secret, anywhere.** Sign-in uses PKCE: the browser invents a secret,
sends only its fingerprint, and proves itself later. A public app needs no stored secret,
and this package will not accept one.

## Using it

```vue
<template>
  <header>
    <CosyUserMenu />
  </header>
</template>
```

`<CosyUserMenu />` shows who is signed in and a **Sign out** control. It is registered for
you; there is nothing to import.

### Its colours are yours

The menu follows **your page**, never the reader's operating system. It ships light, and
every colour is a CSS custom property you can set from your own stylesheet:

| Property | What it paints | Light default |
|---|---|---|
| `--cosy-menu-fg` | the name and the button label | `#1f2937` |
| `--cosy-menu-bg` | the button's fill | `#ffffff` (dark `#1f2937`) |
| `--cosy-menu-surface` | the ground under the whole menu | `transparent` (dark `#111827`) |
| `--cosy-menu-border` | the button's border | `#9ca3af` |
| `--cosy-menu-border-hover` | that border under the pointer | `#1f2937` |
| `--cosy-menu-accent` | the focus ring | `#2563eb` |

```css
:root { --cosy-menu-fg: #0b3d2e; --cosy-menu-border: #0b3d2e; }
```

**For a dark page, ask for the dark palette.** Any one of these turns it on, and nothing
else does: `class="dark"` on `<html>` (what Nuxt's colour-mode module sets),
`data-theme="dark"` on `<html>`, or `<CosyUserMenu class="cosy-dark" />`. Set the properties
yourself and you need none of them — don't do both, or the class wins.

This used to read `prefers-color-scheme`, which reports the reader's MACHINE, not your page.
A light page on a dark-mode Mac drew the name at 1.17:1 — invisible. Your page decides now.
Since 0.1.5 the menu also paints **its own ground**: the button has a fill in both palettes,
and the dark palette draws a surface under the whole menu. A host that set `html.dark` over a
light header used to get light text on light; now text and ground always come from one palette.

**The module's own pages** (`/auth/no-access`, `/auth/callback`) follow the same signal, and
since 0.1.5 each draws a small card with **its own ground**, so the text is readable whatever
colour your page underneath is. Before, a host that set `html.dark` over a light page got light
text on light, 1.17:1. Set any of these from your stylesheet:

| Property | What it paints | Light default | Dark |
|---|---|---|---|
| `--cosy-page-fg` | the sentence | `#1f2937` | `#e5e7eb` |
| `--cosy-page-bg` | the card's ground | `#ffffff` | `#111827` |
| `--cosy-page-card-border` | the card's edge | `#e5e7eb` | `#374151` |

```ts
const { ready, isAuthenticated, user, hasRole, hasCosyRight, login, logout } = useCosySatelliteAuth()
```

Wait for `ready` before you decide what to show. It turns true once the app has looked for
an existing session, whether or not it found one.

Protect a page:

```vue
<script setup lang="ts">
definePageMeta({ middleware: 'cosy-auth' })
</script>
```

Someone signed out is sent to sign in, and comes back to the page they were heading for.
Someone signed in who lacks `requiredRole` reads a plain sentence saying they do not have
access yet and who to ask. Never a 403, never a blank page.

### Who can view the whole app (0.1.8)

The organisation that owns your app chooses, in Co-Sy, who can view it: **Public** or
**Requires login**. You configure nothing for this. Every page asks Co-Sy once.

Public, nothing changes: anyone browses, and only pages that name `cosy-auth` need a sign-in.
Requires login, every page needs a sign-in by someone holding `requiredRole`. Someone signed out
is sent to sign in and brought back. Someone signed in without the role reads the refusal page.
The server renders none of your pages for a Requires-login app: it sends the visitor to the
module's waiting page, `/auth/gate`, which hands them on from the browser.

It fails closed. If Co-Sy cannot be reached, the app is treated as Requires login.
It gates pages, not files: data your own server hands out without a token is still yours to guard.

The sign-in return page (`/auth/callback`) and the waiting page show nothing while they work.
A small spinner appears only if the hand-back takes longer than 400 ms.

**Hide as well as refuse.** The guard refuses on the route. Hiding the link is yours:

```vue
<NuxtLink v-if="hasRole('WHALE_PROTECTOR_USER')" to="/whales">Whales</NuxtLink>
```

Call Co-Sy's API:

```ts
const api = useCosyApi()
const spaces = await api<{ items: unknown[] }>('/v1/co-spaces')
```

It attaches the access token, renews it once if the call comes back unauthorised, and hands
you the payload. When something fails it throws a `CosyApiError` whose `message` is the
sentence Co-Sy itself wrote for the person — show that, not a status code. Its `requestId`
is the reference a person can quote to support.

### When the person's access changes (since 0.1.6)

A token carries the person's roles for its whole life. When Co-Sy changes them, it refuses
the older token with 401 and `error.code: 'TOKEN_STALE'`. `useCosyApi` then:

- waits about 2.25 seconds, so the new token is minted after Co-Sy's change has settled;
- asks Zitadel for a new token with this app's own refresh token;
- retries the call once with it.

Calls refused together share one re-mint. If the retry is refused as stale again, or the
re-mint fails, the session ends here and the person is sent to sign in. It never loops.
Any other 401 behaves as before.

Why not Co-Sy's own `POST /api/v1/auth/refresh`? That route reads Co-Sy's own refresh
cookie, accepts only Co-Sy's own origin, and mints a token for Co-Sy, not for this app.
So the package applies the same wait to its own token. The wait tracks Co-Sy's default
`RECENTLY_CHANGED_SETTLE_MS` of 1000 ms; if Co-Sy raises it, raise
`COSY_STALE_SETTLE_MS` in `src/runtime/auth.ts` to match.

**Give other widgets the same re-mint.** `getFreshToken` is auto-imported:

```ts
await getFreshToken()        // the current token, renewed first if it is about to expire
await getFreshToken(refused) // after Co-Sy answered TOKEN_STALE to `refused`: the new token
```

Pass the token Co-Sy refused. The widget then waits on the same re-mint as `useCosyApi`,
so the page mints once. Retry the refused call once with the answer. Stop if that is stale
too. `null` means nobody is signed in, or the re-mint failed. It never navigates; hide the
widget. For Snag (0.1.21 and later), in `app/snag.provider.ts`:

```ts
export default (() => {
  const { ready, session, isAuthenticated } = useCosySatelliteAuth()
  let lastGiven: string | null = null // the token Snag was last given
  return {
    token: () => (lastGiven = ready.value ? session.value?.accessToken ?? null : null),
    refreshToken: () => getFreshToken(lastGiven),
    actingOrg: () => null,
    active: () => ready.value && isAuthenticated.value,
  }
}) satisfies SnagProvider
```

Snag 0.1.21's hook is `refreshToken`, and it takes no argument. Snag calls it once, after
Co-Sy answered 401, then retries with the token it returns. So the provider remembers the
token it last handed Snag, and passes that to `getFreshToken` as the refused one.

### Calling your own back end (since 0.1.7)

Your satellite's back end checks the token with `@co-sy/satellite-guard`. Call it through
`useSatelliteApi`, auto-imported, with your API's base:

```ts
const api = useSatelliteApi(useRuntimeConfig().public.apiBase)
const sightings = await api<Sighting[]>('/sightings')
await api('/sightings', { method: 'POST', body: { species: 'humpback' } })
```

It puts the person's token on the call as `Authorization: Bearer <token>`. It hands back
your back end's answer as it was sent. A Co-Sy-style envelope is unwrapped to its `data`.

The guard refuses a stale token with 401 and `{ statusCode, error: 'TOKEN_STALE', message }`.
`useSatelliteApi` treats that exactly as `useCosyApi` treats Co-Sy's own TOKEN_STALE. It
waits the same settle window, re-mints once and retries once. A Co-Sy-envelope TOKEN_STALE
from your back end is recognised too.

The re-mint is the SAME one `useCosyApi` and `getFreshToken` use. A stale refusal from Co-Sy
and one from your back end at the same moment share one re-mint. A second stale goes to
sign-in, never a loop. Any other 401 refreshes once and retries once, with no sign-in.

Any refusal throws a `CosyApiError`. Its `message` is your back end's own sentence, its
`code` the guard's `error` (`ROLE_REQUIRED`, `TOKEN_EXPIRED`…), its `status` the HTTP status.

Optional hooks, in a file of your own:

```ts
// app/cosy.provider.ts
import type { CosySatelliteProvider } from '@co-sy/satellite-auth'

export default (() => ({
  onSignedIn: session => console.log('welcome', session.claims.email),
  onSignedOut: () => {},
  actingOrg: () => '392299888888888888', // an organisation ID — Co-Sy matches organisations by id, never by slug
})) satisfies CosySatelliteProvider
```

On a satellite the acting organisation comes from the registry row that registered this
app. This setting cannot change it. `actingOrg` forwards a literal string into an
`X-Acting-Org` header, and Co-Sy only honours that header on its own front-end's path, when
the caller's generic-roles map shows that organisation — a satellite token's never does. So
on a satellite this setting decides nothing, and it is dead if left unset, which is why
Positive Polar's own app sets none. It is retained here only for hosts that also run Co-Sy's
own front-end path, where the caller genuinely can carry more than one organisation's rights.

Then set `provider: '~/cosy.provider'`. **Do not write a Nuxt plugin that calls into this
package.** The module owns its own plugin. A hand-written one survives the off switch and
then breaks every page — which is exactly what happened to `@co-sy/snag` at 0.1.4.

### Pretend you're logged out (0.1.11, strict parity since 0.1.12, every site since 0.1.13)

A signed-in person can see the site as a visitor does, without signing out of Co-Sy.
Add the item to your account menu, one line beside your other items:

```vue
<CosyPretendLoggedOutItem :as="DropdownMenuItem" />          <!-- your own menu-item component -->
<CosyPretendLoggedOutItem as="panel" class="…" @done="…" />   <!-- a plain button you style -->
```

It shows to a signed-in person on every site, Public or Requires login (0.1.13). Choosing it, in that tab:

- The session accessor answers "no session": `session` is null, `isAuthenticated` is false, `user` is null and no role is held, so your header shows "Sign in".
- A thin banner, "Pretending you're logged out", sits at the foot of every page with a "Stop pretending" button. The module mounts it; you add nothing.
- A read to your API or Co-Sy goes without the token. `getFreshToken()` answers null, so Snag stands down.
- A write is refused before it is sent, as a `CosyApiError` with code `PRETENDING_LOGGED_OUT` and the sentence "You're pretending to be logged out. Stop pretending to do this."
- Wherever a visitor is sent to sign in, so is the person: a guarded page, a Requires-login site, your own "Sign in". Co-Sy's sign-in brings them back, and that return ends the pretence.
- On a Requires-login site, choosing it takes the person straight to Co-Sy's sign-in page, as a visitor is taken. No page of your site shows, so neither does the banner. There are two ways out: sign in on Co-Sy's page (that ends the pretence), or close the tab.

It ends on "Stop pretending", on the next sign-in, on sign-out, and when the session ends.
A refresh keeps it; a new tab does not (it lives in that tab's `sessionStorage`).
It is a preview aid, not a security control: the session and its tokens stay valid, and your API never learns of it.
There is no server-side flag: the pretence lives only in that tab's `sessionStorage`, so your site's server and your API see a visitor.
`useCosySatelliteAuth()` also gives `pretending`, `startPretending()`, `stopPretending()` and `pretendWords` for a host that builds its own control.
The banner's colours are custom properties: `--cosy-pretend-bg`, `--cosy-pretend-fg`, `--cosy-pretend-accent`.

## The session rule — read this one

**This app holds its own tokens, on its own website.**

Co-Sy's own front-end keeps its sign-in in a cookie that the browser will only ever send
back to Co-Sy's own domain. That is deliberate and it is good security. It also means the
cookie **cannot** reach a satellite on a different domain. A satellite that waits for it
waits forever.

So this package signs the person in against the satellite's OWN application in Zitadel,
gets its own tokens back, and renews them itself. Nothing here reads, needs or relies on
Co-Sy's cookie, and nothing ever will.

**Where the session is kept, and what that costs (since 0.1.9).** On your own website,
under one key, in one of two places. You choose with `sessionScope`.

- `'browser'`, the default, keeps it in `localStorage`. Every tab of this browser on your site
  shares it. A page opened in a new tab is signed in at once. Co-Sy's "Show on page" for a
  Snag opens your page that way, so it goes straight through the gate. A sign-out in one tab
  signs the other tabs out too.
- `'tab'` keeps it in `sessionStorage`. That was the only behaviour before 0.1.9. Each tab
  signs in on its own, and the session is gone when the tab closes.

Both survive a page refresh. Neither falls back to the other: a page reads only the place
you chose. Signing out clears both.

**How long it lasts (since 0.1.10, Mark, 9 Oct 2026).** Under `'browser'`, the sign-in ends
after **one hour unused**. Every sign-in, renewal, API call and page change counts as use.
A sign-in unused for longer is dropped the next time any tab looks at it. Close the site,
come back thirty minutes later, and you are still in. Come back two hours later, and you
sign in again. `'tab'` has no idle timer; it ends when the tab closes.

**"Keep me signed in on this device"** is a per-device choice, off by default. When it is on,
the limit is **fourteen days unused** instead of an hour. The usual range for remember-me is
14 to 30 days. We take the short end: the token sits on the device, so less time is less risk.

**Platform admins are offered it, and it is ignored for them.** A token that carries Co-Sy's
platform-admin role (`super_admin`, in the Co-Sy project's keyed claim) always ends after an
hour unused. The toggle still shows, because the person who next signs in on this device may
be someone else. Today this check finds nobody: Co-Sy does not yet put the platform-admin role
into satellite tokens. It takes effect once Co-Sy does (a Co-Sy back change, parked under 086).
The module does not widen its scopes to find it.

**Sign-out in any tab ends it in every tab.** The refresh token is dropped from every store.
An idled-out session is dropped the same way. It is not revoked at Zitadel: this module does
not know Zitadel's revocation endpoint, so the token is discarded here and left to expire there.

Show the toggle in your own account menu, with the module's words:

```ts
const { canRememberDevice, rememberDevice, setRememberDevice, rememberDeviceWords } = useCosySatelliteAuth()
// label: rememberDeviceWords.label
// hint:  canRememberDevice ? rememberDeviceWords.hint : rememberDeviceWords.platformAdminHint
```

`setRememberDevice` stores the flag for anyone and returns whether it is honoured right now.

The costs, stated plainly. JavaScript running on your site can read either place, so a
script injection on your site could steal the sign-in. Do not load script you do not trust.
`'browser'` costs more: the sign-in also outlives the tab and the browser restart, for up to
an hour unused. With "Keep me signed in on this device" ticked, it lasts up to fourteen days
unused. Zitadel's own limit still applies on top: 30 days unused, or 90 days at most. On a
shared computer, the next person at the keyboard is still signed in for that time, unless
the first one signed out.

Mark chose `'browser'` as the default on 9 Oct 2026, knowing both costs. He had declined it
a month or two before; opening a Snag's page in a new tab and meeting a sign-in every time
changed his mind. The same afternoon he ruled it too open for too long: "It's really just
for the current session." Hence the hour, and remember-me as the person's own choice.

**This module never uses an iframe.** The session is renewed with the refresh token from
the PKCE exchange, against the token endpoint. There is no silent renew, no check-session
iframe and no hidden frame of any kind. This is PROVED, not asserted: a search of the whole
source for `iframe`, `silent`, `check_session` and `prompt=none` finds nothing but two
comments. Say why it matters: a real site sets `Content-Security-Policy: frame-ancestors
'none'` and `X-Frame-Options: DENY`, and an iframe-based renewal would fail on every such
site. Nobody should ever be asked to loosen those headers for this module.

**Start the host with its port named explicitly.** A dev server silently takes the next
free port when its own is busy, and the redirect then stops matching what Zitadel holds.

**Before the first sign-in, check the printed address equals the registered origin,
character for character.** A trailing slash, or `127.0.0.1` where `localhost` is
registered, is the commonest first failure — and it presents as a Zitadel problem rather
than a typing one.

## What a person must still do in Zitadel by hand

**TURN "ASSERT ROLES ON AUTHENTICATION" OFF on the satellite's own project — do this
first.** This fails SILENTLY: with it ON, Zitadel drops every role that came from another
project, there is no error anywhere, and the integration merely looks broken. If a
satellite's people sign in but nobody has access, check this before anything else.

**Same symptom, a further cause:** an audience scope built in zsh with `$VAR:a` expands
`:a` as a path modifier, so the scope silently becomes a filesystem path and the token
arrives with no roles; build scopes inside the script, never in the shell.

Before a satellite can work, a Co-Sy platform administrator sets these up too. None of it
can be done from this package.

1. **A project for the satellite**, and a role in it — the one you put in `requiredRole`.
2. **An application inside that project**: type "User Agent", PKCE, **no client secret**.
   Its redirect URI must be your site's `callbackPath` (`https://your.site/auth/callback`)
   and its post-logout URI your `postLogoutPath` (`https://your.site/`).
3. **Grant the satellite's project access to the Co-Sy project**, so a person's Co-Sy
   rights are carried in the token too.
4. **Give each person their role** in the satellite's project.

## Turning it off

```ts
cosySatellite: { enabled: false, /* …the rest, left in place… */ }
```

Off, nothing is registered and nothing of this package is in the built site. Not disabled —
absent. There is a test that builds a real app both ways and searches the whole output to
prove it (`npm run test:build`).

## Checks

```bash
npm test          # unit tests
npm run typecheck # types
npm run build     # the published files
npm run test:build # builds a real app twice and searches its output
```

---

Part of the Cooperating System. Not licensed for redistribution.
